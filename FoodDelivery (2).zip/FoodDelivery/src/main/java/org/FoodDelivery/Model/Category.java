//package org.FoodDelivery.Model;
//
//public class Category {
//
//	private String catId;
//	private String catName;
//}
